Summary
=======

Image viewer/Slideshow. Imageview displays attached images directly in TB in ca. 80% of TB screen size. 
They can be zoomed, rotated, mirrored and they can be displayed as a slideshow.

The download dialog box displays a thumbnail of the image. Now, it is easy to decide which image/photo to download to disk.

Zoomed images can be pulled by mouse to display different parts of the image in the viewscreen. 
Click into the image switches between original size and zoomed size.
Installation
============

The easiest way to install Imageview/Slideshow is through Thunderbird`s addon page. It
will automatically update itself when new versions are released.



Authors
=======

Klaus Buecher/opto.

